s=input('nhap chuoi')
for ch in s:
    print(ch.upper())
