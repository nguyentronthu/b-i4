s=input('nhap chuoi')
for ch in s:
   if ch==" ":
       continue
   print(ch)
