ds=input('nhap chuoi: ').split()
x=ds[1:-1]
for c in x:
    print(c)
    
         

