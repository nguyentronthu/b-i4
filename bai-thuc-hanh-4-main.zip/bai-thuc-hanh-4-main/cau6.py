ds= input('danh sach: ').split()
          
print(ds)

for i in ds[::-1]:
    print(i)
