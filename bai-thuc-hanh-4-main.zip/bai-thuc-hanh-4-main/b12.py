ds=input('nhap chuoi').split()
print(ds)
ds.remove('123')
for i in ds:
    print(i)
