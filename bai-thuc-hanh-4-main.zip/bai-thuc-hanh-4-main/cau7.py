b=''
c=input('nhap chuoi:')
for i in c:
    if i.isdigit():
        continue
    b+=i
print(b)
