a="hello guy"
def say():
    global a
    a="vinh university"
    print(a)
say()
print(a)
    
